package draw;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
	public static void main(String[] args) {
		/* Création JFrame*/
		JFrame fenetre = new JFrame("draw");
		Draw draw = new Draw();
		/* ajout de l'Affichage(JPanel) à la fenêtre (JFrame)*/
		fenetre.add(draw);
		fenetre.pack();
		fenetre.setVisible(true);
		fenetre.setFocusable(true);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class Draw extends JPanel{
	public Draw() {
		this.setPreferredSize(new Dimension(800, 800));
	}
	
	private void drawOBS(int x, int y, int width, int height, Graphics g) {
		g.drawRect(x, y, width, height);
	}
	
	@Override
    public void paint(Graphics g) {
		drawOBS(100, 100, 100, 100, g);
		
	}
}